prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>7669530484719925
,p_default_application_id=>101
,p_default_id_offset=>7672187796761339
,p_default_owner=>'WKSP_OCIVISION'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>'Timeline'
,p_alias=>'HOME'
,p_step_title=>'APEX Social Media'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex.actions.add([{',
'    name: "like",',
'    action: (event, element, args) => {',
'        apex.items.P1_ACTION_ID.value = args.id;',
'        apex.event.trigger(document, ''action-like'');',
'        }',
'    }, {',
'    name: "delete",',
'    action: (event, element, args) => {',
'        apex.items.P1_ACTION_ID.value = args.id;',
'        apex.event.trigger(document, ''action-delete'');',
'        }',
'    }]);'))
,p_page_template_options=>'#DEFAULT#'
,p_overwrite_navigation_list=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'MARINA'
,p_last_upd_yyyymmddhh24miss=>'20240607042334'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(61446214708615024)
,p_plug_name=>unistr('\6295\7A3F')
,p_region_template_options=>'#DEFAULT#:js-dialog-autoheight:js-dialog-size480x320:js-headingLevel-1'
,p_plug_template=>wwv_flow_imp.id(63143490774825842463)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_04'
,p_query_type=>'TABLE'
,p_query_table=>'SM_POSTS'
,p_include_rowid_column=>false
,p_is_editable=>false
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(61478459197255094)
,p_plug_name=>'Timeline'
,p_region_name=>'timeline'
,p_region_css_classes=>'t-Chat'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(63142856241217842448)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'p.id,',
'p.created_by AS user_name,',
'p.post_comment AS comment_text,',
'p.file_blob,',
'p.file_mime,    ',
'apex_util.get_since(p.created) post_date,',
'(',
'    select count(*) from SM_REACTIONS smr',
'    where smr.post_id=p.id',
') as REACTIONS,',
'(',
'    select ''user-has-liked'' from SM_REACTIONS smr',
'    where smr.post_id=p.id and created_by=UPPER(:APP_USER)',
') USER_REACTION_CSS',
'from SM_POSTS p',
'order by p.created desc;',
''))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(61478480548255095)
,p_region_id=>wwv_flow_imp.id(61478459197255094)
,p_layout_type=>'GRID'
,p_title_adv_formatting=>false
,p_title_column_name=>'USER_NAME'
,p_sub_title_adv_formatting=>false
,p_sub_title_column_name=>'POST_DATE'
,p_body_adv_formatting=>false
,p_body_column_name=>'COMMENT_TEXT'
,p_second_body_adv_formatting=>false
,p_icon_source_type=>'INITIALS'
,p_icon_class_column_name=>'USER_NAME'
,p_icon_position=>'START'
,p_media_adv_formatting=>false
,p_media_source_type=>'BLOB'
,p_media_blob_column_name=>'FILE_BLOB'
,p_media_display_position=>'FIRST'
,p_media_appearance=>'WIDESCREEN'
,p_media_sizing=>'COVER'
,p_media_css_classes=>'selectDisable'
,p_media_description=>'&COMMENT_TEXT. '
,p_pk1_column_name=>'ID'
,p_mime_type_column_name=>'FILE_MIME'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(61478616859255096)
,p_card_id=>wwv_flow_imp.id(61478480548255095)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>10
,p_label=>'&REACTIONS. '
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#action$like?id=&ID.'
,p_button_display_type=>'TEXT_WITH_ICON'
,p_icon_css_classes=>'fa-heart &USER_REACTION_CSS.'
,p_action_css_classes=>'js-heart-button'
,p_is_hot=>false
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(61478775287255097)
,p_card_id=>wwv_flow_imp.id(61478480548255095)
,p_action_type=>'BUTTON'
,p_position=>'SECONDARY'
,p_display_sequence=>20
,p_label=>'Delete'
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#action$delete?id=&ID.'
,p_button_display_type=>'ICON'
,p_icon_css_classes=>'fa-trash-o'
,p_is_hot=>false
,p_condition_type=>'EXPRESSION'
,p_condition_expr1=>':USER_NAME=:APP_USER'
,p_condition_expr2=>'PLSQL'
,p_exec_cond_for_each_row=>true
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(61477681306255087)
,p_button_sequence=>10
,p_button_name=>'ADD_POST'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(63143588381029842509)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('\6295\7A3F')
,p_button_position=>'AFTER_LOGO'
,p_warn_on_unsaved_changes=>null
,p_button_css_classes=>'new-post-button'
,p_icon_css_classes=>'fa-plus'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(61478061021255090)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_imp.id(61446214708615024)
,p_button_name=>'Save'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(63143588293013842509)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('\6295\7A3F')
,p_button_position=>'NEXT'
,p_warn_on_unsaved_changes=>null
,p_button_css_classes=>'post-button'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(61476594009255076)
,p_name=>'P1_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_is_query_only=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(61446214708615024)
,p_item_source_plug_id=>wwv_flow_imp.id(61446214708615024)
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(61476748459255077)
,p_name=>'P1_POST_COMMENT'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(61446214708615024)
,p_item_source_plug_id=>wwv_flow_imp.id(61446214708615024)
,p_prompt=>unistr('\30B3\30E1\30F3\30C8')
,p_placeholder=>unistr('\30B3\30E1\30F3\30C8\3092\5165\529B\3057\3066\4E0B\3055\3044')
,p_source=>'POST_COMMENT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_imp.id(63143585613918842508)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(61476868558255078)
,p_name=>'P1_FILE_BLOB'
,p_source_data_type=>'BLOB'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(61446214708615024)
,p_item_source_plug_id=>wwv_flow_imp.id(61446214708615024)
,p_prompt=>unistr('\5199\771F')
,p_source=>'FILE_BLOB'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(63143585613918842508)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_is_persistent=>'N'
,p_attribute_01=>'DB_COLUMN'
,p_attribute_02=>'FILE_MIME'
,p_attribute_03=>'FILE_NAME'
,p_attribute_06=>'N'
,p_attribute_11=>'image/*'
,p_attribute_12=>'DROPZONE_BLOCK'
,p_attribute_13=>unistr('\5199\771F\3092\9078\629E')
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(61477127072255081)
,p_name=>'P1_LAT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(61446214708615024)
,p_item_source_plug_id=>wwv_flow_imp.id(61446214708615024)
,p_source=>'LAT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(61477234669255082)
,p_name=>'P1_LON'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(61446214708615024)
,p_item_source_plug_id=>wwv_flow_imp.id(61446214708615024)
,p_source=>'LON'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(61478804674255098)
,p_name=>'P1_ACTION_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(61478459197255094)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(61477848031255088)
,p_name=>'Open Post Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(61477681306255087)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(61477966001255089)
,p_event_id=>wwv_flow_imp.id(61477848031255088)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_OPEN_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(61446214708615024)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(61478090890255091)
,p_name=>'Submit Post'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(61478061021255090)
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex.item(''P1_FILE_BLOB'').value.length>0 ||',
'apex.item(''P1_POST_COMMENT'').value.length>0'))
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(61478216984255092)
,p_event_id=>wwv_flow_imp.id(61478090890255091)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'Save'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(61479080757255101)
,p_name=>'action-like'
,p_event_sequence=>30
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'document'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'custom'
,p_bind_event_type_custom=>'action-like'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(61479201485255102)
,p_event_id=>wwv_flow_imp.id(61479080757255101)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'LIKE - update UI (adjust count + heart color)'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'const button = $(''[data-id="''+ apex.items.P1_ACTION_ID.value +''"] .js-heart-button''); // get the card',
'',
'    const label = button.find(''.a-CardView-buttonLabel''); // get the likes count section',
'',
'    const icon = button.find(''.a-CardView-buttonIcon''); // gets the element if its liked already',
'',
'    let likeCount = label.text(); // get the like count',
'',
'    if (icon.hasClass(''user-has-liked'')) {',
'        // user has liked this already, and they are unliking it now -- decrement',
'        label.text(--likeCount);',
'',
'    } else {',
'        // user is liking the post -- increment',
'        label.text(++likeCount);',
'    }',
'',
'    icon.toggleClass(''user-has-liked''); // either add this class or remove it'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(61479281155255103)
,p_event_id=>wwv_flow_imp.id(61479080757255101)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_name=>'LIKE -- do database work'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    -- try to store this posts'' reaction from this user',
'    insert into SM_REACTIONS (post_id, reaction, lat, lon)',
'        values (:P1_ACTION_ID, ''LIKED'', :P1_LAT, :P1_LON);',
'    exception when dup_val_on_index then',
'        -- remove it as it already existed',
'        delete from SM_REACTIONS where',
'            post_id=:P1_ACTION_ID and created_by=:APP_USER;',
'    end;'))
,p_attribute_02=>'P1_ACTION_ID,P1_LAT,P1_LON'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(61479455075255104)
,p_name=>'action-delete'
,p_event_sequence=>40
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'document'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'custom'
,p_bind_event_type_custom=>'action-delete'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(61479575450255105)
,p_event_id=>wwv_flow_imp.id(61479455075255104)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>unistr('DELETE \2013 Confirm dialog')
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>'You are about to delete this post. Are you sure?'
,p_attribute_02=>'Are you sure?'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(61479595603255106)
,p_event_id=>wwv_flow_imp.id(61479455075255104)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_name=>unistr('DELETE \2013 do database work')
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'delete from SM_POSTS where id=:P1_ACTION_ID and created_by=:APP_USER;'
,p_attribute_02=>'P1_ACTION_ID'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(61479757154255107)
,p_event_id=>wwv_flow_imp.id(61479455075255104)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_name=>unistr('DELETE \2013 remove post in UI')
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$(''[data-id=''+apex.items.P1_ACTION_ID.value+'']'').remove();'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(61478340600255093)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(61446214708615024)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Insert Post'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>unistr('\6295\7A3F\3057\307E\3057\305F\FF01')
,p_internal_uid=>8026164867300418
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(61446324018615025)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(61446214708615024)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Timeline'
,p_internal_uid=>7994148285660350
);
wwv_flow_imp.component_end;
end;
/
